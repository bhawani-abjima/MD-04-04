﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;



abstract class zoo
{
    public abstract void voices();                //abstract keyword uses and declaration
    public void sleep()
    {
        Console.WriteLine("grrgrr grrgrr");
    }
}
class Pig : zoo
{
    public override void voices()
    {
        Console.WriteLine("hugrr hugrr");
    }
}
interface I1
{    
    void printMethod();
}
interface I2
{
    void printMethod();
}
class C : I1, I2
{
    void I1.printMethod()                            //explicit interface decalaration
    {
        Console.WriteLine("I1 printMethod");
    }
    void I2.printMethod()
    {
        Console.WriteLine("I2 printMethod");
    }
}
struct Books
{
    public string title;
    public string author;                          //declaration  of structure
    public string subject;
    public int book_id;

    public interface ITransactions                 //interface declaration
    {
        void showTransaction();
        double getAmount();
    }
    public class Transaction : ITransactions
    {
        private string tCode;
        private string date;
        private double amount;

        public Transaction()
        {
            tCode = " ";
            date = " ";
            amount = 0.0;
        }
        public Transaction(string c, string d, double a)
        {
            tCode = c;
            date = d;
            amount = a;
        }
        public double getAmount()
        {
            return amount;
        }
        public void showTransaction()
        {
            Console.WriteLine("Transaction Details: {0}", tCode);
            Console.WriteLine("Date : {0}", date);
            Console.WriteLine("Amount: {0}", getAmount());
        }
    }

    public struct Customer
    {
        private int _id;
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public int Id
        {
            get { return this._id; }
            set { this._id = value; }
        }
        public Customer(int id, string Name)
        {
            this._id = id;
            this._name = Name;
        }
        public void PrintDetails()
        {
            Console.WriteLine("ID={0} && Name={1}", this._id, this._name);
        }
    }

    public class Program
    {
        public static void addition(int a, int b)
        {
            Console.WriteLine(a + b);
        }
        public static void multiplication(int a, int b)
        {
            Console.WriteLine(a * b);
        }
        public static void sub(int a, int b)
        {
            Console.WriteLine(Math.Abs(a - b));
        }


        public delegate void addnum(int a, int b);              //Using delegates keyword
       
        public static void sum(int a, int b)
        {
            Console.WriteLine("(900 + 110) = {0}", a + b);
        }
        public static void subtract(int a, int b)
        {
            Console.WriteLine("(800 - 60) = {0}", a - b);
        }
       public static void Main(string[] args)
        {
            addnum TWR = new addnum(sum);
            TWR(3, 4);
            addnum sub = new addnum(subtract);
            sub(4, 5);

            addnum add_ob = new addnum(addition);
            add_ob(49, 63);
            addnum mult_ob = new addnum(multiplication);
            mult_ob(39, 40);


            Customer C1 = new Customer(100101, "Sgt.Mactavis");
            C1.PrintDetails();
            Customer C2 = new Customer(100102, "Sgt.Ghost");
            C2.PrintDetails();
            Customer C3 = new Customer();
            C3.Id = 100105;
            C3.Name = "Sgt.Roger";
            C3.PrintDetails();



            Books Book1;
            Books Book2;


            Book1.title = "1 Evidence";                  //using structure values
            Book1.author = "Cris Evans";
            Book1.subject = "Murder";
            Book1.book_id = 124449;


            Book2.title = "Lost world";
            Book2.author = "Hamesworth";
            Book2.subject = "24 hours";
            Book2.book_id = 898966;


            Console.WriteLine("Book 1 title : {0}", Book1.title);
            Console.WriteLine("Book 1 author : {0}", Book1.author);
            Console.WriteLine("Book 1 subject : {0}", Book1.subject);
            Console.WriteLine("Book 1 book_id :{0}", Book1.book_id);


            Console.WriteLine("Book 2 title : {0}", Book2.title);
            Console.WriteLine("Book 2 author : {0}", Book2.author);
            Console.WriteLine("Book 2 subject : {0}", Book2.subject);
            Console.WriteLine("Book 2 book_id : {0}", Book2.book_id);


            Transaction t1 = new Transaction("00ASDF00H5", "8/10/2015", 852400.00);
            Transaction t2 = new Transaction("00ASDF00K9", "9/10/2011", 901500.00);

            t1.showTransaction();
            t2.showTransaction();

            I1 i1 = new C();
            I2 i2 = new C();
            i1.printMethod();    //explicit method calling 
            i2.printMethod();


            Pig myPig = new Pig();
            myPig.voices();  
            myPig.sleep();  

            Console.ReadKey();
        }
    }
}